import numpy as np

# Define the parameters for the two distributions
mu1 = np.array([1, 1])
mu2 = np.array([-1, -1])
sigma1 = np.array([[1, 0.6], [0.6, 1]])
sigma2 = np.array([[1, -0.9], [-0.9, 1]])

# Generate half of the points from N(x|µ1, Σ1)
n = 50
points1 = np.random.multivariate_normal(mu1, sigma1, n)

# Generate the other half of the points from N(x|µ2, Σ2)
points2 = np.random.multivariate_normal(mu2, sigma2, n)

# Concatenate the two sets of points
points = np.concatenate((points1, points2))

# Print the generated points
for i, point in enumerate(points):
    print(f"X{i+1}: {point}")
