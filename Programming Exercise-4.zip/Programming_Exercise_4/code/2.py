import numpy as np


def initialize_parameters():
    mu1 = np.array([-10, 10])
    mu2 = np.array([10, -10])
    sigma1 = np.array([[1, 0], [0, 1]])
    sigma2 = np.array([[1, 0], [0, 1]])
    pi1 = 0.5
    return mu1, mu2, sigma1, sigma2, pi1


def calculate_prob(x, mu, sigma):
    d = x.shape[0]
    det = np.linalg.det(sigma)
    inv = np.linalg.inv(sigma)
    coefficient = 1 / (np.power((2 * np.pi), d / 2) * np.sqrt(det))
    exponent = -0.5 * np.dot(np.dot((x - mu).T, inv), (x - mu))
    return coefficient * np.exp(exponent)


def expectation_step(X, mu1, mu2, sigma1, sigma2, pi1):
    N = X.shape[0]
    gamma = np.zeros((N, 2))

    for i in range(N):
        x = X[i]
        prob1 = calculate_prob(x, mu1, sigma1)
        prob2 = calculate_prob(x, mu2, sigma2)
        gamma[i, 0] = (pi1 * prob1) / (pi1 * prob1 + (1 - pi1) * prob2)
        gamma[i, 1] = ((1 - pi1) * prob2) / (pi1 * prob1 + (1 - pi1) * prob2)

    return gamma


def maximization_step(X, gamma):
    N = X.shape[0]
    d = X.shape[1]
    mu1 = np.sum(gamma[:, 0].reshape(-1, 1) * X, axis=0) / np.sum(gamma[:, 0])
    mu2 = np.sum(gamma[:, 1].reshape(-1, 1) * X, axis=0) / np.sum(gamma[:, 1])
    sigma1 = np.zeros((d, d))
    sigma2 = np.zeros((d, d))
    pi1 = np.sum(gamma[:, 0]) / N

    for i in range(N):
        x = X[i]
        sigma1 += gamma[i, 0] * np.outer((x - mu1), (x - mu1))
        sigma2 += gamma[i, 1] * np.outer((x - mu2), (x - mu2))

    sigma1 /= np.sum(gamma[:, 0])
    sigma2 /= np.sum(gamma[:, 1])

    return mu1, mu2, sigma1, sigma2, pi1


def likelihood(X, mu1, mu2, sigma1, sigma2, pi1):
    N = X.shape[0]
    likelihood = 0

    for i in range(N):
        x = X[i]
        prob1 = calculate_prob(x, mu1, sigma1)
        prob2 = calculate_prob(x, mu2, sigma2)
        likelihood += np.log(pi1 * prob1 + (1 - pi1) * prob2)

    return likelihood


def EM_algorithm(X, epsilon=0.001):
    mu1, mu2, sigma1, sigma2, pi1 = initialize_parameters()
    likelihood_prev = float('-inf')

    while True:
        gamma = expectation_step(X, mu1, mu2, sigma1, sigma2, pi1)
        mu1, mu2, sigma1, sigma2, pi1 = maximization_step(X, gamma)
        likelihood_current = likelihood(X, mu1, mu2, sigma1, sigma2, pi1)

        if likelihood_current - likelihood_prev < epsilon:
            break

        likelihood_prev = likelihood_current

    return mu1, mu2, sigma1, sigma2, pi1


# Generate the dataset
np.random.seed(0)
mu1_true = np.array([1, 1])
mu2_true = np.array([-1, -1])
sigma1_true = np.array([[1, 0.6], [0.6, 1]])
sigma2_true = np.array([[1, -0.9], [-0.9, 1]])
n = 50
points1 = np.random.multivariate_normal(mu1_true, sigma1_true, n)
points2 = np.random.multivariate_normal(mu2_true, sigma2_true, n)
X = np.concatenate((points1, points2))

# Run the EM algorithm
mu1_hat, mu2_hat, sigma1_hat, sigma2_hat, pi1_hat = EM_algorithm(X)

# Print the estimated parameters
print("Estimated Parameters:")
print("mu1_hat:", mu1_hat)
print("mu2_hat:", mu2_hat)
print("sigma1_hat:", sigma1_hat)
print("sigma2_hat:", sigma2_hat)
print("pi1_hat:", pi1_hat)
