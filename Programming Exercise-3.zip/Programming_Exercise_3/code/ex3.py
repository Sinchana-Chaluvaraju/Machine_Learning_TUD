import numpy as np
import time


# Generate random factors with dimensions based on problem statement
def generate_factors(seed, c):
    np.random.seed(seed)

    # Generate factors with given dimensions
    f1 = np.random.random((c, c))
    f2 = np.random.random((c, c, c))
    f3 = np.random.random((c,))
    f4 = np.random.random((c, c))
    f5 = np.random.random((c,))

    return f1, f2, f3, f4, f5


# Implementing the sum-product algorithm
def message_passing_sum_product(c, f1, f2, f3, f4, f5):
    # Messages from leaf nodes to the root
    m_x5_x4 = np.sum(f4 * f5[:, np.newaxis], axis=0)
    m_x4_x2 = np.sum(f2 * m_x5_x4[np.newaxis, np.newaxis, :], axis=2)
    m_x3_x2 = np.sum(f2 * f3[:, np.newaxis, np.newaxis], axis=1)
    m_x2_x1 = np.sum(f1 * (m_x4_x2[:, np.newaxis] * m_x3_x2[:, np.newaxis]), axis=0)

    # Compute marginals
    marginal_x1 = (m_x2_x1)
    marginal_x2 = (
        np.sum(f1 * m_x2_x1[:, np.newaxis], axis=0) * np.sum(m_x4_x2, axis=0) * np.sum(m_x3_x2, axis=0)
    )
    marginal_x3 = (np.sum(f2 * m_x4_x2[np.newaxis, :, :], axis=(1, 2)) * f3)
    marginal_x4 = (np.sum(f2 * m_x3_x2[:, np.newaxis, np.newaxis], axis=(0, 1)) * m_x5_x4)
    marginal_x5 = (
        np.sum(f4 * np.sum(f2 * f3[:, np.newaxis, np.newaxis], axis=1), axis=0) * f5
    )

    return marginal_x1, marginal_x2, marginal_x3, marginal_x4, marginal_x5


# Naive computation of marginals
def compute_naive_marginals(c, f1, f2, f3, f4, f5):
    joint = np.zeros((c, c, c, c, c))
    for x1 in range(c):
        for x2 in range(c):
            for x3 in range(c):
                for x4 in range(c):
                    for x5 in range(c):
                        joint[x1, x2, x3, x4, x5] = f1[x1, x2] * f2[x2, x3, x4] * f3[x3] * f4[x4, x5] * f5[x5]

    joint = (joint)

    marginal_x1 = np.sum(joint, axis=(1, 2, 3, 4))
    marginal_x2 = np.sum(joint, axis=(0, 2, 3, 4))
    marginal_x3 = np.sum(joint, axis=(0, 1, 3, 4))
    marginal_x4 = np.sum(joint, axis=(0, 1, 2, 4))
    marginal_x5 = np.sum(joint, axis=(0, 1, 2, 3))

    return (marginal_x1), (marginal_x2), (marginal_x3), (marginal_x4), (
        marginal_x5)


# Main execution
def main():
    c = 2
#    c = np.random.choice([2, 10, 20, 50])
    seed = 100

    f1, f2, f3, f4, f5 = generate_factors(seed, c)

    start_time = time.time()
    marginals = message_passing_sum_product(c, f1, f2, f3, f4, f5)
    end_time = time.time()
    sum_product_time = end_time - start_time

    print("Marginals computed using Sum-Product Algorithm:")
    for i, marginal in enumerate(marginals):
        print(f"P(x{i + 1}) = {marginal}")

    print(f"Execution time for sum-product algorithm: {sum_product_time:.10f} seconds")

    start_time = time.time()
    naive_marginals = compute_naive_marginals(c, f1, f2, f3, f4, f5)
    end_time = time.time()
    naive_time = end_time - start_time

    print("Marginals computed using Naive Method:")
    for i, marginal in enumerate(naive_marginals):
        print(f"P(x{i + 1}) = {marginal}")

    print(f"Execution time for naive algorithm: {naive_time:.10f} seconds")


if __name__ == "__main__":
    main()
