import numpy as np
import matplotlib.pyplot as plt

def rosenbrock_density(x1, x2):
    Z = 0.0625  # Normalization constant
    return np.exp(-100*(x2 - x1**2)**2 - (1 - x1)**2) / Z

def proposal_distribution(x, sigma=0.5):
    return np.random.multivariate_normal(x, [[sigma**2, 0], [0, sigma**2]])

def metropolis_hastings(iterations, sigma, x0):
    samples = [x0]
    current_sample = x0
    for _ in range(iterations):
        proposed_sample = proposal_distribution(current_sample, sigma)
        acceptance_prob = min(1, rosenbrock_density(*proposed_sample) / rosenbrock_density(*current_sample))
        if np.random.rand() < acceptance_prob:
            current_sample = proposed_sample
        samples.append(current_sample)
    return np.array(samples)

# Parameters
L = 10**5
sigma = 0.5
x0 = np.array([0, 10])

# Run Metropolis-Hastings algorithm
samples = metropolis_hastings(L, sigma, x0)

# Plot the generated sequence
plt.figure(figsize=(8, 6))
plt.plot(samples[:, 0], samples[:, 1], marker='o', markersize=2, linestyle='-', color='blue', alpha=0.5)
plt.xlabel('$x_1$', fontsize=14)
plt.ylabel('$x_2$', fontsize=14)
plt.title('Metropolis-Hastings Sampling: Rosenbrock Density Function', fontsize=16)
plt.grid(True)
plt.show()
