import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal


# Define the Rosenbrock density function
def rosenbrock(x):
    return np.exp(-((100 * (x[1] - x[0] ** 2) ** 2 + (1 - x[0]) ** 2) / 20))


# Define the proposal distribution
def proposal_distribution(x, sigma):
    return multivariate_normal.rvs(mean=x, cov=sigma ** 2 * np.eye(2))


# Define Metropolis-Hastings algorithm
def metropolis_hastings(likelihood, proposal, x0, sigma, num_samples):
    samples = [x0]
    accepted = 0

    for _ in range(num_samples):
        x_prev = samples[-1]
        x_proposed = proposal(x_prev, sigma)
        alpha = min(1, likelihood(x_proposed) / likelihood(x_prev))

        if np.random.rand() < alpha:
            samples.append(x_proposed)
            accepted += 1
        else:
            samples.append(x_prev)

    return np.array(samples[1:]), accepted / num_samples


# Compute auto-correlation function
def auto_correlation(samples, lag):
    L = len(samples)
    s_bar = np.mean(samples, axis=0)
    numerator = np.mean((samples[:L - lag] - s_bar) * (samples[lag:] - s_bar), axis=0)
    denominator = np.mean((samples - s_bar) ** 2, axis=0)
    return numerator / denominator


# Generate sequence
def generate_sequence(L, sigma, x0):
    samples, _ = metropolis_hastings(rosenbrock, proposal_distribution, x0, sigma, L)
    return samples


# Plot sequence
def plot_sequence(samples):
    plt.figure(figsize=(8, 6))
    plt.scatter(samples[:, 0], samples[:, 1], marker='.', color='b', alpha=0.5)
    plt.xlabel('$x_1$')
    plt.ylabel('$x_2$')
    plt.title('Generated Sequence')
    plt.grid(True)
    plt.show()


# Plot trace plot
def plot_trace_plot(samples):
    plt.figure(figsize=(10, 4))
    plt.subplot(1, 2, 1)
    plt.plot(samples[:, 0])
    plt.xlabel('Iteration')
    plt.ylabel('$x_1$')
    plt.title('Trace Plot of $x_1$')

    plt.subplot(1, 2, 2)
    plt.plot(samples[:, 1])
    plt.xlabel('Iteration')
    plt.ylabel('$x_2$')
    plt.title('Trace Plot of $x_2$')

    plt.tight_layout()
    plt.show()


# Compute and plot auto-correlation function
def plot_auto_correlation(samples, sigma_values):
    for sigma in sigma_values:
        auto_corr_x1 = [auto_correlation(samples[:, 0], lag) for lag in range(1, 2001)]
        auto_corr_x2 = [auto_correlation(samples[:, 1], lag) for lag in range(1, 2001)]

        plt.figure(figsize=(10, 4))
        plt.plot(auto_corr_x1, label='$x_1$')
        plt.plot(auto_corr_x2, label='$x_2$')
        plt.xlabel('lag (k)')
        plt.ylabel('$r_k$')
        plt.title(f'Auto-correlation Function for $\sigma$ = {sigma}')
        plt.legend()
        plt.grid(True)
        plt.show()


# Main function
def main():
    L = int(1e5)
    sigma_values = [0.1, 0.5, 1]
    x0 = np.array([0, 10])

    # Generate sequence
    samples = generate_sequence(L, 0.5, x0)

    # Plot sequence
    plot_sequence(samples)

    # Plot trace plot
    plot_trace_plot(samples)

    # Plot auto-correlation function
    plot_auto_correlation(samples, sigma_values)


if __name__ == "__main__":
    main()
