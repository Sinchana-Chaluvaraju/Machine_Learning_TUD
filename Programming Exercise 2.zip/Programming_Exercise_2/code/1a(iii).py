import numpy as np
import matplotlib.pyplot as plt


def rosenbrock_density(x1, x2):
    return np.exp(- (100 * (x2 - x1 ** 2) ** 2 + (1 - x1) ** 2) / 20)


def metropolis_hastings(L, sigma, x0):
    samples = [x0]
    current = x0
    accepted = 0

    for _ in range(L):
        proposal = np.random.multivariate_normal(current, [[sigma ** 2, 0], [0, sigma ** 2]])
        acceptance_ratio = (rosenbrock_density(proposal[0], proposal[1]) /
                            rosenbrock_density(current[0], current[1]))
        acceptance_ratio *= np.exp(-np.sum((current - proposal) ** 2) / (2 * sigma ** 2)) / \
                            np.exp(-np.sum((proposal - current) ** 2) / (2 * sigma ** 2))

        if np.random.rand() < min(1, acceptance_ratio):
            current = proposal
            accepted += 1
        samples.append(current)

    return np.array(samples), accepted / L


# Parameters
L = 10 ** 5
x0 = np.array([0, 10])
sigma_min = 0
delta_sigma = 0.05
num_iterations = 21

acceptance_rates = []

for i in range(num_iterations):
    sigma = sigma_min + i * delta_sigma
    _, acceptance_rate = metropolis_hastings(L, sigma, x0)
    acceptance_rates.append(acceptance_rate)

# Plotting the acceptance rates
sigma_values = sigma_min + np.arange(num_iterations) * delta_sigma
plt.plot(sigma_values ** 2, acceptance_rates, marker='o')
plt.xlabel(r'$\sigma^2$')
plt.ylabel('Acceptance Rate')
plt.title('Acceptance Rate vs. $\sigma^2$')
plt.grid(True)
plt.show()
