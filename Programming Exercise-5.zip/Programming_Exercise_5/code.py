import numpy as np
import scipy.io
import matplotlib.pyplot as plt

# Step 1: Load the dataset for a chosen digit
filename = 'eights.mat'  # Update with the actual filename
digit_data = scipy.io.loadmat(filename)
digit_dataset = digit_data['X']

# Step 2: Implement PCA algorithm
def pca(dataset, M):
    # Center the data
    centered_data = dataset - np.mean(dataset, axis=1, keepdims=True)

    # Compute the covariance matrix
    covariance_matrix = np.cov(centered_data)

    # Compute the eigenvectors and eigenvalues
    eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)

    # Sort eigenvectors in decreasing order of eigenvalues
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]

    # Select the top M eigenvectors
    selected_eigenvectors = sorted_eigenvectors[:, :M]

    # Project the data onto the subspace spanned by the eigenvectors
    projected_data = np.dot(selected_eigenvectors.T, centered_data)

    # Reconstruct the data from the projected subspace
    reconstructed_data = np.dot(selected_eigenvectors, projected_data) + np.mean(dataset, axis=1, keepdims=True)

    return reconstructed_data

# Step 3: Calculate approximation error
chosen_digit = 0  # Choose the digit (0-9)
M_values = [5, 30, 100]  # Dimensions of the linear subspace

# Choose five images from the dataset
selected_images = digit_dataset[:, chosen_digit]

# Calculate approximation error for different M values
for M in M_values:
    reconstructed_images = pca(X, M)

    # Calculate approximation error
    N = selected_images.shape[1]
    approximation_error = np.linalg.norm(selected_images - reconstructed_images) / np.sqrt(N)

    print(f"Approximation Error (M={M}): {approximation_error}")

    # Plotting original and reconstructed images side by side
    fig, axes = plt.subplots(2, 5, figsize=(10, 4))
    for i in range(5):
        axes[0, i].imshow(selected_images[:, i].reshape(28, 28), cmap='gray')
        axes[0, i].axis('off')
        axes[1, i].imshow(reconstructed_images[:, i].reshape(28, 28), cmap='gray')
        axes[1, i].axis('off')

    axes[0, 2].set_title('Original Images')
    axes[1, 2].set_title(f'Reconstructed Images (M={M})')

    plt.show()
